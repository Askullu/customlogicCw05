sap.ui.define(['sap/fe/core/AppComponent'], function(AppComponent) {
    'use strict';

    return AppComponent.extend('com.sap.bp.BusinessPartners.Component', {
        metadata: {
            manifest: 'json'
        }
    });
});
